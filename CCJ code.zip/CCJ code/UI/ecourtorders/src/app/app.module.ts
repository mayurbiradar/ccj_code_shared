import { BrowserModule, } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms'
import { TreeviewModule } from 'ngx-treeview';
import {DataViewModule} from 'primeng/dataview';
import {TabViewModule} from 'primeng/tabview';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import {DialogModule} from 'primeng/dialog';
import {ChipsModule} from 'primeng/chips';
import {InputTextModule} from 'primeng/inputtext';
import {PaginatorModule} from 'primeng/paginator';
import {AutoCompleteModule} from 'primeng/autocomplete';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { LoginComponent } from './login/login.component';
import { SafePipe } from './models/urlPipe';
import { StatePipe } from './models/statePipe';

import { AppService } from './app.service';
import { HighlightSearch } from './models/highlight';
import { BlogsComponent } from './blogs/blogs.component';
import { AccordianComponent } from './accordian/accordian.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import {MessageService} from 'primeng/api';
import { FeedbackComponent } from './feedback/feedback.component';
import { IframeComponent } from './iframe/iframe.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SearchResultComponent,
    LoginComponent,
    SafePipe,
    HighlightSearch,
    StatePipe,
    BlogsComponent,
    AccordianComponent,
    BlogDetailsComponent,
    HeaderComponent,
    FooterComponent,
    FeedbackComponent,
    IframeComponent
  ] ,
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    DataViewModule,
    TabViewModule,
    ToastModule,
    CheckboxModule,
    DialogModule,
    ChipsModule,
    InputTextModule,
    PaginatorModule,
    AutoCompleteModule,
    TreeviewModule.forRoot()
  ],
  providers: [AppService,MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }

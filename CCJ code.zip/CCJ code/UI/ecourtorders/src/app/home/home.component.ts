import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router'
import { MessageService } from 'primeng/api';
import { Feedback } from '../models/feedback';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  selectedCities: string[] = [];
  checked: boolean = false;
  sections: any[];
  searchText:string='';
  routeState: string = 'home';

  userName:string="";
  userMob:string="";
  userEmail:string="";
  userFeed:string="";


  constructor(private appService: AppService, private route: Router,private messageService: MessageService) {
  }

  routeTo:string;

  @ViewChild('home') home: ElementRef;
  @ViewChild('about') about: ElementRef;
  @ViewChild('pricing') pricing: ElementRef;
  @ViewChild('contact') contact: ElementRef;
  ngOnInit() {    
    this.appService.routeVariable.subscribe(objj => {
      this.routeState = objj;
      this.scroll(this.routeState);
      
    })



  }

  scroll($event) { 
    var ele=$event;
    if (ele == "about") {
      this.about.nativeElement.scrollIntoView();

    } else if (ele == "pricing") {
      this.pricing.nativeElement.scrollIntoView();

    } else if (ele == "contact") {
      this.contact.nativeElement.scrollIntoView();

    } else if (ele == "home") {
      this.home.nativeElement.scrollIntoView();
    }
  }

  search(txt) {
    if(txt.type=='section')
    {
      var obj={text:txt.text.name,type:txt.type}
      this.appService.searchHitFromHomepage(obj)
    }else{
      this.appService.searchHitFromHomepage(txt)
    }
   
    this.route.navigate(['/search'])
  }


  filterSectionSingle(event) {
  let query = event.query;
  this.appService.fetchSections(query).then(res => {
    console.log(res)
    this.sections = res.data;
  });
  }


  submitFeed(feed)
  {
    let f=new Feedback(feed.uname,feed.uemail,feed.ufeed,feed.umob);
    this.appService.submitFeedback(f)
    .then(res => {
      if (res.success) {
       
        this.messageService.add({severity:'success', summary: "Submitted", detail:''});
      }else{
        this.messageService.add({severity:'warn', summary: res.message, detail:''});

      }
    })
    .catch(err=>{
      this.messageService.add({severity:'error', summary: 'Something went wrong', detail:''});
    })

    this.userEmail="";
    this.userFeed="";
    this.userName="";
    this.userMob="";
  }

}

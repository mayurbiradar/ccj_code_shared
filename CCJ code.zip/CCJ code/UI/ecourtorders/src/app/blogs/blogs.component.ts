import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.css']
})
export class BlogsComponent implements OnInit {

  routeTo:string;
  fullname:string="";
  email:string="";
  constructor(private appService:AppService,private route:Router) { }

  ngOnInit() {
    this.fullname=localStorage.getItem('fname')+" "+localStorage.getItem('lname');
    this.email=localStorage.getItem('uemail');
  }

  openBlog()
  {
    this.route.navigate(['blogdetails'])
  }


}

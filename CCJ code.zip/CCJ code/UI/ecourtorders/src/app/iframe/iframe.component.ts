import { Component, OnInit } from '@angular/core';
import { Dialog } from 'primeng/dialog';
import { AppService } from '../app.service';

@Component({
  selector: 'app-iframe',
  templateUrl: './iframe.component.html',
  styleUrls: ['./iframe.component.css']
})
export class IframeComponent implements OnInit {
  display: boolean = false;


  constructor(private appService: AppService) { }

  ngOnInit() {
  }

  loginOverlay() {
    this.appService.toggleLoginOverlay('block');
  }



}

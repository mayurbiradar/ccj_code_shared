import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'highlight'
})

export class HighlightSearch implements PipeTransform {

    transform(value: any, args: any): any {
        if (!args) {return value;}

        var len = args.length,
            i = 0;

            var newValue=value;
          for (; i < len; i++) {
            var re = new RegExp(args[i], 'i');
            newValue=newValue.replace(re, "<span class='highlight'>" + args[i] + "</span>");
          }        
        
        return newValue;
    }
}
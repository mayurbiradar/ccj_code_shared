export class Login{
    uemail:string;
    upass:string;
}
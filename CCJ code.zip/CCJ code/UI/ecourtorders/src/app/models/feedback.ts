export class Feedback{
    uname:string;
    uemail:string;
    ufeed:string;
    umob:string;

    constructor(uname,uemail,ufeed,umob){
        this.uemail=uemail;
        this.uname=uname;
        this.ufeed=ufeed;
        this.umob=umob;
    }
}
export class UserDetails{
    uemail:string;
    fname:string;
    lname:string;
    isEmailVerfied:string;
}
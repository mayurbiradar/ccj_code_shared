export class Request{
    uemail:string;
    skey:string;
}
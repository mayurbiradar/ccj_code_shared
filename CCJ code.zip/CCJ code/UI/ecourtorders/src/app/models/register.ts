export class Register{
    uemail:string;
    upass:string;
    fname:string;
    lname:string;
}
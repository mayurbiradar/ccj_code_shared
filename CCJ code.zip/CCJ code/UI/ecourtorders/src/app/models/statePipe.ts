import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'statepipe' })
export class StatePipe implements PipeTransform {
  constructor() {}
  transform(items: any[], slist: any[]): any {
    if (slist.length==0 || slist===undefined) return items;
    if (items.length==0 || items===undefined) return [];
    return items.filter(it =>{
        return slist.includes(it.j_state)
    })
}
}
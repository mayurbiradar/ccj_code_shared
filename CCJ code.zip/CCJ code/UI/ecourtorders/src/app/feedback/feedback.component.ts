import { Component, OnInit } from '@angular/core';
import { Feedback } from '../models/feedback';
import { AppService } from '../app.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  displayFeedback:string="none";
  userName:string="";
  userEmail:string="";
  userFeed:string="";
  userMob:string="";
  constructor(private appService: AppService,private messageService: MessageService) { }

  ngOnInit() {
  }

  toggleFeedback()
  {
    this.displayFeedback=='none'?this.displayFeedback='block':this.displayFeedback='none'
  }

  submitFeed(feed)
  {
    this.displayFeedback='none'
    let f=new Feedback(feed.uname,feed.uemail,feed.ufeed,feed.umob);
    this.appService.submitFeedback(f)
    .then(res => {
      if (res.success) {
       
        this.messageService.add({severity:'success', summary: res.message, detail:''});
      }else{
        this.displayFeedback='none'
        this.messageService.add({severity:'warn', summary: res.message, detail:''});

      }
    })
    .catch(err=>{
      this.displayFeedback='none'
      this.messageService.add({severity:'error', summary: 'Something went wrong', detail:''});
    })

    this.userEmail="";
    this.userFeed="";
    this.userName="";
  }
}

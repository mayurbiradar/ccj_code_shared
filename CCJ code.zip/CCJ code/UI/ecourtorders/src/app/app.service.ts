import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Login } from './models/login';
import { Register } from './models/register';
import { Request } from './models/request';
import { Feedback } from './models/feedback';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }
  loginFlag:string='none';
  private showLoginOverlay = new BehaviorSubject(this.loginFlag);
  loginFlagVariable = this.showLoginOverlay.asObservable();

  toggleLoginOverlay(x:string) {
    
    if(x=='block'){
      this.toggleAccordian('none')
    }
    this.showLoginOverlay.next(x)
  }

  //  httpOptions = {
  //   withCredentials: false,
  //   headers: new HttpHeaders({ 
  //     'Content-Type': 'application/json',
  //     'charset': 'UTF-8',
  //   })
  // };

  routeFlag:string='';
  private routeHome = new BehaviorSubject(this.routeFlag);
  routeVariable = this.routeHome.asObservable();

  routeToDashboard(x:string) {
    this.routeHome.next(x)
  }



  message:string='';
  private messageValue = new BehaviorSubject(this.message);
  messageFlag = this.messageValue.asObservable();

  toastMessage(x:string) {
    this.messageValue.next(x)
  }






  searchtext:any={};

  private searchText = new BehaviorSubject(this.searchtext);
  searchTextFromHomePage = this.searchText.asObservable();

  searchHitFromHomepage(x:any) {
    this.searchText.next(x)
  }


  loginFLag:boolean=false;
  private isLoggedIn = new BehaviorSubject(this.loginFLag);
  isLoggedInVariable = this.isLoggedIn.asObservable();
  toggleLoggedIn(x:boolean) {
    this.isLoggedIn.next(x)
  }


  accFlag:string='none';
  private tAccordian = new BehaviorSubject(this.accFlag);
  accFlagValue = this.tAccordian.asObservable();
  toggleAccordian(x:string) {
    this.tAccordian.next(x)
  }

  downloadPDF(url): any {
    return this.http.get(url, { responseType: 'blob'}).toPromise()
            .then(res => {
            return new Blob([res], { type: 'application/pdf', });
        });
  }
  search(searchTexts:any[],stateArr:any[],offset:number){
    return this.http.post( environment.API_ENDPOINT + '/fetchPDFs',{texts:searchTexts,states:stateArr,offset:offset}).toPromise()
    .then(res=><any>res);
  }

  searchBySection(searchTexts:any[],stateArr:any[],offset:number){
    return this.http.post( environment.API_ENDPOINT + '/fetchPdfBySection',{texts:searchTexts,states:stateArr,offset:offset}).toPromise()
    .then(res=><any>res);
  }


  fetchStates(){
    return this.http.get( environment.API_ENDPOINT + '/fetchAllStates').toPromise()
    .then(res=><any>res);
  }

  
  fetchSections(txt:string){
    return this.http.post( environment.API_ENDPOINT + '/fetchAllSections',{text:txt}).toPromise()
    .then(res=><any>res);
  }

  validateSession(){
    return this.http.get( environment.API_ENDPOINT + '/validate').toPromise()
    .then(res=><any>res);
  }

  login(login:Login){
  
    return this.http.post( environment.API_ENDPOINT + '/login',login).toPromise()
    .then(res=><any>res);
  } 

  logout(req:Request){
    return this.http.post( environment.API_ENDPOINT + '/logout',req).toPromise()
    .then(res=><any>res);
  } 

  register(reg:Register){
  return this.http.post( environment.API_ENDPOINT + '/register',reg).toPromise()
    .then(res=><any>res);
  } 

  submitFeedback(feed:Feedback){
    return this.http.post( environment.API_ENDPOINT + '/feed',feed).toPromise()
      .then(res=><any>res);
    } 
}

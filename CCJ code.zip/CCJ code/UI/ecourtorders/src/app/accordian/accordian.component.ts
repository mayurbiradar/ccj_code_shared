import { Component, OnInit, Output, EventEmitter ,HostListener, AfterViewInit} from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accordian',
  templateUrl: './accordian.component.html',
  styleUrls: ['./accordian.component.css']
})
export class AccordianComponent implements OnInit,AfterViewInit {
  ngAfterViewInit(): void {
    this.appService.accFlagValue.subscribe(obj => this.isAccodianOpen = obj);
  }
  showLoginOverlay: string = 'none';
  loggedIn:boolean=false;
  isAccodianOpen: string = 'none';

  ngOnInit() {
    this.appService.toggleLoginOverlay('none')
    this.appService.loginFlagVariable.subscribe(obj => this.showLoginOverlay = obj);
    localStorage.getItem('uemail')!=null?this.loggedIn=true:this.loggedIn=false;

    this.appService.toggleLoggedIn(this.loggedIn);
    this.appService.isLoggedInVariable.subscribe(obj => this.loggedIn = obj);
  }
  constructor(private appService: AppService,private route:Router) {}

  @Output() routeTo = new EventEmitter<string>();

  @HostListener('document:click')
  clickout()
  {
    if(this.isAccodianOpen=='block')
    {
      //this.appService.toggleAccordian('none')
    }
  }

  loginOverlay() {
    if (this.showLoginOverlay == "none") {
      this.showLoginOverlay = "block"
    } else {
      this.showLoginOverlay = "none"
    }

  
   
    this.appService.toggleLoginOverlay(this.showLoginOverlay)
  }

  openBlogPage(){
    this.route.navigate(['/blogs'])
  }

  logout()
  {
    localStorage.clear();
    this.appService.toggleLoggedIn(false);
    this.appService.toggleAccordian('none');
    this.appService.toastMessage('Logout Successful')

  }
}


import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Login } from '../models/login';
import { templateJitUrl } from '@angular/compiler';
import { Router } from '@angular/router'
import { Register } from '../models/register';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private appService: AppService, private route: Router) { }
  loginClickStatus: boolean = true;
  signUpClickStatus: boolean = false;
  forgotPassClicked: boolean = false;
  uemail: string = "";
  fname: string = "";
  lname: string = "";
  upass: string = "";
  currentUrl: string = '';
  emailErr: string = "";
  reqErr: string = "";
  resErr: string = "";
  ngOnInit() {
    this.loginClickStatus = true;
    this.forgotPassClicked = false;
    this.signUpClickStatus = false;
    this.currentUrl = this.route.url;
    this.appService.loginFlagVariable.subscribe(obj => {
      this.resetFields();
    });
  }

  loginOverlay() {
    this.appService.toggleLoginOverlay('none')
  }

  login(log) {
    this.resErr = "";
    if (this.validateForm()) {
      this.loginOverlay();
      let login = new Login();
      login.uemail = log.uemail;
      login.upass = log.upass;
      this.appService.login(login).then(res => {
        if (res.success) {
          this.appService.toastMessage('Login Successful')
          localStorage.setItem('uemail', login.uemail)
          localStorage.setItem('fname', res.data[0].fname)
          localStorage.setItem('lname', res.data[0].lname)
          localStorage.setItem('isEmailVerified', res.data[0].isEmailVerified)
          this.upass = "";
          this.appService.toggleLoggedIn(true);
          this.uemail = "";
          this.upass = "";
          if (this.currentUrl != '/search') {
            this.route.navigate(['/search'])
          }

        } else {
          this.resErr = res.message;
        }
      })
    }
  }


  resetFields() {
    this.reqErr = "";
    this.resErr = "";
    this.emailErr = "";
    this.uemail = "";
    this.upass = "";
    this.fname = "";
    this.lname = "";
  }

  resetErrMsgs() {
    this.reqErr = "";
    this.resErr = "";
    this.emailErr = "";
  }


  register(reg) {
    if(this.validateRegForm())
    {
      let r = new Register();
      r.uemail = reg.uemail;
      r.upass = reg.upass;
      r.fname = reg.fname;
      r.lname = reg.lname;
      this.appService.register(r).then(res => {
        if (res.success) {
          this.loginOverlay();
          this.appService.toastMessage(res.message)
          
        } else {
         this.resErr=res.message
        }
      })
    }
   

  }

  validateForm() {
    var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
    var flag = false;

    if (this.uemail == "") {
      this.emailErr = "Enter email";
    }
    else if (!this.uemail.match(reEmail)) {
      this.emailErr = "Invalid email";

    } else if (this.upass == "") {
      this.emailErr = "";
      this.reqErr = "This field is mandatory";
    } else {
      this.emailErr = "";
      this.reqErr = "";
      flag = true;
    }

    return flag;
  }


  validateRegForm() {
    var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
    var flag = false;

    if (this.uemail == "") {
      this.emailErr = "Enter email";
    }
    else if (!this.uemail.match(reEmail)) {
      this.emailErr = "Invalid email";
    } else if (this.upass == "") {
      this.emailErr = "";
      this.reqErr = "This field is mandatory";
    } else if (this.fname == "") {
      this.emailErr = "";
      this.reqErr = "This field is mandatory";
    } else if (this.lname == "") {
      this.emailErr = "";
      this.reqErr = "This field is mandatory";
    } else {
      this.emailErr = "";
      this.reqErr = "";
      flag = true;
    }

    return flag;
  }
}

import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { AppService } from '../app.service';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { Router } from '@angular/router'
import { Request } from '../models/request';
import { MessageService } from 'primeng/api';
import { enterView } from '@angular/core/src/render3/state';
import { environment } from 'src/environments/environment.prod';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit, AfterViewInit {

  searchText: string = "";
  searchTextBackup: string = "";
  searchKeyword: string = "";
  searchResult: any[] = [];
  filteredSearchResult: any[] = [];
  loggedIn: boolean = false;
  highLightText: string = "";
  stateList: any[] = [];
  fullname: string = "";
  email: string = "";
  totalRecords: number = 0;
  isEmailVerified: boolean = false;
  showLoading: boolean = false;
  pdfToShow: string = "";
  dropdownEnabled = true;
  items: TreeviewItem[];
  values: number[];
  routeTo: string;
  blurrStyle: string = "3px";
  searchKeywords: string[] = [];
  paginatorValue:number=0;
  config = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: false,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  config2 = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: false,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  constructor(private appService: AppService, private route: Router, private messageService: MessageService) { }

  ngOnInit() {

    var searchObject={};

    this.appService.searchTextFromHomePage.subscribe(objj => 
      {
        if(objj.type!=undefined)
        {
          searchObject=objj;
        }
      }
     )

     if(searchObject!={})
     {
       console.log(searchObject)
      this.search(searchObject)
     }



    this.appService.isLoggedInVariable.subscribe(objj => {
      this.loggedIn = objj;
      this.fullname = localStorage.getItem('fname') + " " + localStorage.getItem('lname');
      this.email = localStorage.getItem('uemail');
    })
    this.fullname = localStorage.getItem('fname') + " " + localStorage.getItem('lname');
    this.email = localStorage.getItem('uemail');
    localStorage.getItem('uemail') != null ? this.loggedIn = true : this.loggedIn = false;
    this.appService.toggleLoggedIn(this.loggedIn);
    localStorage.getItem('isEmailVerified') == 'Y' ? this.isEmailVerified = true : this.isEmailVerified = false;

    this.appService.fetchStates().then(res => {
      const stateList = new TreeviewItem({
        text: 'States', value: 1, collapsed: true, children: res.data
      });
      this.items = [stateList];
    });
  }

  ngAfterViewInit(): void {
    this.appService.messageFlag.subscribe(objj => {
      if (objj != '') {
        this.messageService.add({ severity: 'success', summary: objj, detail: '' });
      }
    }
    )
  }

  stateChange:boolean=false;
  onSelectedChange(value: any[]) {
    this.stateList = value;
    if ((value.length > 0 &&  this.searchTextBackup!="")|| this.stateChange) {
      this.stateChange=true;
      var keyArr = this.searchKeywords
      var stateArr = this.stateList
      this.searchKeyword = "";
      this.showLoading = true;
      const interval = setInterval(() => {
        this.appService.search(keyArr,stateArr,0)
          .then(res => {
            this.searchResult= res.data;
            this.showLoading = false;
            if(res.total==undefined)
            {
              this.totalRecords=0;
            }else{
              this.totalRecords=res.total;

            }
            this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});

          })
          .catch(err => {
            this.showLoading = false;
            this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
          })

          clearInterval(interval)
        }, 1)
    }
  }


  onRemoveChip()
  {
    if(this.searchKeywords.length==0)
    {
      this.searchKeywords.push(this.searchTextBackup)
      this.messageService.add({ severity: 'error', summary: "You can't remove all elements", detail: '' });
    }else{
      var keyArr = this.searchKeywords
      var stateArr = this.stateList
      this.searchKeyword = "";
      this.showLoading = true;
      const interval = setInterval(() => {
        this.appService.search(keyArr,stateArr,0)
          .then(res => {
            this.searchResult= res.data;
            this.showLoading = false;
            if(res.total==undefined)
            {
              this.totalRecords=0;
            }else{
              this.totalRecords=res.total;

            }
            this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});

          })
          .catch(err => {
            this.showLoading = false;
            this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
          })

          clearInterval(interval)
        }, 1)

    }
      
  }

  loginOverlay() {
    this.appService.toggleLoginOverlay('block');
  }


  addSearchKeyword(searchKeyword) {
    if (searchKeyword != "") {
      this.searchKeywords.push(searchKeyword)
      var keyArr = this.searchKeywords
      var stateArr = this.stateList
      this.searchKeyword = "";
      this.showLoading = true;
      const interval = setInterval(() => {

        if(keyArr[0].includes('section'))
        {
          this.appService.searchBySection(keyArr,stateArr,0)
          .then(res => {
            this.searchResult= res.data;
            this.showLoading = false;
            if(res.total==undefined)
            {
              this.totalRecords=0;
            }else{
              this.totalRecords=res.total;

            }
            this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});

          })
          .catch(err => {
            this.showLoading = false;
            this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
          })
        }else{
          this.appService.search(keyArr,stateArr,0)
          .then(res => {
            this.searchResult= res.data;
            this.showLoading = false;
            if(res.total==undefined)
            {
              this.totalRecords=0;
            }else{
              this.totalRecords=res.total;

            }
            this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});

          })
          .catch(err => {
            this.showLoading = false;
            this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
          })

        }
      

          clearInterval(interval)
        }, 1)

    }
  }

  search(objj) {
    if(objj.type=='word')
    {
      let searchText=objj.text;
      this.searchTextBackup=searchText;
      if (searchText != "") {
        this.searchKeywords = [];
        this.searchKeywords.push(searchText)
        this.showLoading = true;
        var keyArr = this.searchKeywords
        var stateArr = this.stateList
        const interval = setInterval(() => {
          this.appService.search(keyArr,stateArr,0)
            .then(res => {
              this.searchResult= res.data;
              this.showLoading = false;
              if(res.total==undefined)
              {
                this.totalRecords=0;
              }else{
                this.totalRecords=res.total;
              }
              this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});
  
            })
            .catch(err => {
              this.showLoading = false;
              this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
            })
  
          this.highLightText = searchText;
          this.searchText = "";
          this.appService.searchHitFromHomepage({});
          clearInterval(interval)
        }, 1)
  
      }
    }else if(objj.type=='section')
    {
      let searchText=objj.text;
      this.searchTextBackup=searchText;
      if (searchText != "") {
        this.searchKeywords = [];
        this.searchKeywords.push(searchText)
        this.showLoading = true;
        var keyArr = this.searchKeywords
        var stateArr = this.stateList
        const interval = setInterval(() => {
          this.appService.searchBySection(keyArr,stateArr,0)
            .then(res => {
              this.searchResult= res.data;
              this.showLoading = false;
              if(res.total==undefined)
              {
                this.totalRecords=0;
              }else{
                this.totalRecords=res.total;
              }
              this.messageService.add({ severity: 'success', summary: 'Total records found :', detail: '' + this.totalRecords});
  
            })
            .catch(err => {
              this.showLoading = false;
              this.messageService.add({ severity: 'error', summary: 'Something went wrong', detail: '' });
            })
  
          this.highLightText = searchText;
          this.searchText = "";
          this.appService.searchHitFromHomepage({});
          clearInterval(interval)
        }, 1)
  
      }

      
    }


  

  }

  paginate(event) {
    
    this.showLoading = true;
    this.paginatorValue=event.first;
    const interval = setInterval(() => {
      var keyArr = this.searchKeywords
      var stateArr = this.stateList
      
      if(keyArr[0].includes('section'))
      {
        this.appService.searchBySection(keyArr,stateArr,event.first)
        .then(res => {
          this.searchResult= res.data;
          this.showLoading = false;
        })
      }else{
        this.appService.search(keyArr,stateArr,event.first)
      .then(res => {
        this.searchResult= res.data;
        this.showLoading = false;
      })
      }
      
      clearInterval(interval)
    }, 1)

 
}


  downloadPDF(url) {

    this.appService
      .downloadPDF(url)
      .then(data => {
        const fileUrl = URL.createObjectURL(data);
        let tab = window.open();
        tab.location.href = fileUrl;
      });
  }


  showPdf(obj) {
    if (!this.loggedIn && (obj.index<2 && this.paginatorValue==0)) {
      this.pdfToShow = obj.j_path;

    }else if(!this.loggedIn &&  (obj.index>1 && this.paginatorValue==0)){
      this.pdfToShow=environment.LOCAL_URL;
    }else if(!this.loggedIn &&  this.paginatorValue>0){
      this.pdfToShow=environment.LOCAL_URL;
    }else{
      this.pdfToShow = obj.j_path;
    }
   
  }

  // checkLoginAndBlurr(ind) {

  //   if (this.loggedIn) {
  //     this.blurrStyle = "";
  //   } else {
  //     if (ind >= 2) {
  //       this.blurrStyle = "3px"
  //       //this.appService.toggleLoginOverlay('block')
  //     }
  //   }
  // }

}

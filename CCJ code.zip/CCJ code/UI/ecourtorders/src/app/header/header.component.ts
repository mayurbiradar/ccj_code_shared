import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isCollapsed: string = 'none';
  loggedIn:boolean=false;
  showLoginOverlay: string = 'none';
  constructor(private appService:AppService,private route:Router) { }
  ngOnInit() {
    this.appService.toggleLoginOverlay('none')
    this.appService.loginFlagVariable.subscribe(obj => this.showLoginOverlay = obj);
    this.appService.accFlagValue.subscribe(obj => this.isCollapsed = obj);
    localStorage.getItem('uemail')!=null?this.loggedIn=true:this.loggedIn=false;
    this.appService.toggleLoggedIn(this.loggedIn);
    this.appService.isLoggedInVariable.subscribe(obj => this.loggedIn = obj);
  }

  openBlogPage(){
    this.route.navigate(['/blogs'])
  }

  scroll(ele) { 
    this.appService.routeToDashboard(ele)
    this.appService.toggleAccordian('none')
    this.route.navigate(['/home'])
}

loginOverlay() {
  if (this.showLoginOverlay == "none") {
    this.showLoginOverlay = "block"
  } else {
    this.showLoginOverlay = "none"
  }
 
  this.appService.toggleLoginOverlay(this.showLoginOverlay)
}

logout()
{
  localStorage.clear();
  this.appService.toggleLoggedIn(false);
  this.appService.toastMessage('Logout Successful')
}


topMenu() {
  if (this.isCollapsed=='none') {
    this.appService.toggleAccordian('block')
  } else {
    this.appService.toggleAccordian('none')
  }

}

}

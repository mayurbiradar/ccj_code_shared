import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { BlogsComponent } from './blogs/blogs.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { HeaderComponent } from './header/header.component';
import { AccordianComponent } from './accordian/accordian.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { IframeComponent } from './iframe/iframe.component';
const routes: Routes = [
  {  path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'search',
    component: SearchResultComponent
  },
  {
    path: 'blogs',
    component: BlogsComponent
  },
  {
    path: 'blogdetails',
    component: BlogDetailsComponent
  },
  {
    path: 'iframe',
    component: IframeComponent
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

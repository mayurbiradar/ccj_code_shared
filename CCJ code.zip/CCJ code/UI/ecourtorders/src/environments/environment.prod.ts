export const environment = {
  production: true,
  API_ENDPOINT:'http://137.59.54.252:8000/ecourt',
  LOCAL_URL:'http://courtcasejournal.com/iframe'
};

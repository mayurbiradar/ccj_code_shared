from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import json
import base64
import mysql.connector
import os
import uuid
from .gmail import GMAIL
from django.db import connections
from .models import *
from django.core import serializers
from datetime import datetime
import re

mydb =connections['default']
mycursor = mydb.cursor()
# Create your views here.

def index(request):
    return render(request, template_name='index.html', content_type="text/html")

def hello(request):
    text = {'name':'Mayur','role':'admin'}
    request.session['username'] = 'cool'
    return JsonResponse(text)


def login(request):    
    if request.method == 'POST':
        content=json.loads(request.body)
        uemail=content['uemail']
        upass=base64.b64encode(bytes(content['upass'], 'utf-8'))
        myresult=Auth.objects.filter(user_email=uemail)
        if(len(myresult)>0):
            myresult2=Auth.objects.filter(user_email=uemail,user_pass=upass)
            if(len(myresult2)>0): 
                request.session['username'] = uemail
                request.session.modified=True
                user=UserDetails.objects.filter(user_id=myresult2[0].user_id)
                res={'success':True,'message':'Login successful','data':[{'user_id':user[0].user_id,'fname':user[0].user_first_name,'lname':user[0].user_last_name,'isEmailVerified':user[0].user_email_verfied}]}
                return JsonResponse(res)
            else:
                res={'success':False,'message':'Bad credentials'}
                return JsonResponse(res)
        else:
            res={'success':False,'message':'User does not exist'}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request id POST not GET'}
        return JsonResponse(res)
        
        
def validate(request):
    if request.method == 'GET':
        if(vaidateSession(request)):
            res={'success':True,'message':'Session exist'}
            return JsonResponse(res)
        else:
            res={'success':False,'message':'Session not exist'}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is GET not POST'}
        return JsonResponse(res)
        
        
        
def vaidateSession(request):
    if request.session.has_key('username'):
        return True
    else:
        return False
        
def fetchPDFs(request):
    if request.method == 'POST':
        result_list = []
        content = json.loads(request.body)
        search_txts=content['texts']
        states=content['states']
        st=""
        if(len(states)>0):
            st=', '.join(['"{}"'.format(value) for value in states])
            st= "AND journal_state in ("+st+")"
                
        offset=content['offset']
        where=""
        for i in range(0, len(search_txts)):
            if i==0:
                where="WHERE MATCH(journal_content) AGAINST("+"'"+search_txts[i]+"'"+" IN NATURAL LANGUAGE MODE)"
            else:
                where=where+" AND MATCH(journal_content) AGAINST("+"'"+search_txts[i]+"'"+" IN NATURAL LANGUAGE MODE)"
        
        if st!="":
            sql="SELECT COUNT(*) as journal_id FROM journals "+where+" "+st
        else:
            sql="SELECT COUNT(*) as journal_id FROM journals "+where
            
        myresult=Journals.objects.raw(sql)    
        total=myresult[0].journal_id
        if st!="":
            myresult=Journals.objects.raw("SELECT journal_id,journal_state,journal_title,journal_date,journal_path,journal_content FROM journals "+where+" "+st+ " order by journal_id limit 5 offset "+ str(offset))
        else:
            myresult=Journals.objects.raw("SELECT journal_id,journal_state,journal_title,journal_date,journal_path,journal_content FROM journals "+where+ " order by journal_id limit 5 offset "+ str(offset))      
        if(len(myresult)>0):
            for row in myresult:
                j_state=row.journal_state
                j_title=row.journal_title
                j_date=row.journal_date
                j_path=row.journal_path
                j_path='http://localhost:8000/'+j_path.replace(os.path.sep, '/')
                j_content=row.journal_content
                j_content_list=(" ".join(j_content.replace(u"\xa0", " ").strip().split())).split(".")
                s1=' '.join(j_content_list)
                # content_list=[t for t in j_content_list for ele in search_txts if ele.lower() in t.lower()]
                finalString=""
                for ele in search_txts:
                    r2=re.search(r"(?:[a-zA-Z'-]+[^a-zA-Z'-]+){0,5}"+ele.lower()+r"(?:[^a-zA-Z'-]+[a-zA-Z'-]+){0,5}", s1.lower())
                    if r2 is not None:
                        finalString=finalString+" "+str(r2.group())
                resObject={'j_state':j_state,'j_title':j_title,'j_date':j_date,'j_path':j_path,'j_content':finalString,'j_content_full':j_content}
                result_list.append(resObject)
            res={'success':True,'message':'Fetched result','data':result_list,'total':total}
            return JsonResponse(res)
        else:
            res={'success':True,'message':'Fetched result','data':result_list}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is POST not GET','data':result_list}
        return JsonResponse(res)
    
    
def fetchPdfBySection(request):
    if request.method == 'POST':
        result_list = []
        content = json.loads(request.body)
        search_txts=content['texts']
        states=content['states']
        st=""
        if(len(states)>0):
            st=', '.join(['"{}"'.format(value) for value in states])
            st= "AND journal_state in ("+st+")"
                
        offset=content['offset']
        where=""
        for i in range(0, len(search_txts)):
            if i==0:
                where="WHERE journal_id in (select distinct(journal_id) from sections where section_name like '"+search_txts[i]+"')"            
              
        if st!="":
            sql="SELECT COUNT(*) as journal_id FROM journals "+where+" "+st
        else:
            sql="SELECT COUNT(*) as journal_id FROM journals "+where
            
        myresult=Journals.objects.raw(sql)    
        total=myresult[0].journal_id
  
        if st!="":
            myresult=Journals.objects.raw("SELECT journal_id,journal_state,journal_title,journal_date,journal_path,journal_content FROM journals "+where+" "+st+ " order by journal_id limit 5 offset "+ str(offset))
        else:
            myresult=Journals.objects.raw("SELECT journal_id,journal_state,journal_title,journal_date,journal_path,journal_content FROM journals "+where+ " order by journal_id limit 5 offset "+ str(offset))      
        if(len(myresult)>0):
            for row in myresult:
                j_state=row.journal_state
                j_title=row.journal_title
                j_date=row.journal_date
                j_path=row.journal_path
                j_path='http://localhost:8000/'+j_path.replace(os.path.sep, '/')
                j_content=row.journal_content
                j_content_list=(" ".join(j_content.replace(u"\xa0", " ").strip().split())).split(".")
                s1=' '.join(j_content_list)
                # content_list=[t for t in j_content_list for ele in search_txts if ele.lower() in t.lower()]
                finalString=""
                for ele in search_txts:
                    r2=re.search(r"(?:[a-zA-Z'-]+[^a-zA-Z'-]+){0,5}"+ele.lower()+r"(?:[^a-zA-Z'-]+[a-zA-Z'-]+){0,5}", s1.lower())
                    if r2 is not None:
                        finalString=finalString+" "+str(r2.group())  
                resObject={'j_state':j_state,'j_title':j_title,'j_date':j_date,'j_path':j_path,'j_content':finalString,'j_content_full':j_content}
                result_list.append(resObject)
            res={'success':True,'message':'Fetched result','data':result_list,'total':total}
            return JsonResponse(res)
        else:
            res={'success':True,'message':'Fetched result','data':result_list}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is POST not GET','data':result_list}
        return JsonResponse(res)
    
    
def fetchAllStates(request):
    result_list=[]
    if request.method == 'GET':
        myresult=Journals.objects.values('journal_state').distinct();   
        if(len(myresult)>0):
            for row in myresult:
                e={ 'text':row['journal_state'], 'value': row['journal_state'],'checked': False}
                result_list.append(e)
            res={'success':True,'message':'State List fetched','data':result_list}
            return JsonResponse(res)
        else:
            res={'success':True,'message':'Fetched result','data':result_list}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is GET not POST','data':result_list}
        return JsonResponse(res)
    
    
def fetchAllSections(request):
    result_list=[]
    if request.method == 'POST':
        content = json.loads(request.body)
        search_txt=content['text']
        myresult=Sections.objects.values('section_name').filter(section_name__contains=search_txt).distinct();   
        if(len(myresult)>0):
            for row in myresult:
                e={'name':row['section_name']}
                result_list.append(e)
            res={'success':True,'message':'Sections List fetched','data':result_list}
            return JsonResponse(res)
        else:
            res={'success':True,'message':'Sections List fetched','data':result_list}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is POST not GET','data':result_list}
        return JsonResponse(res)

def register(request):
    if request.method == 'POST':
        try:
            content =json.loads(request.body)
            fname=content['fname']
            lname=content['lname']
            upass=base64.b64encode(bytes(content['upass'], 'utf-8'))      
            uemail=content['uemail'] 
            myresult=Auth.objects.filter(user_email=uemail)
            if len(myresult)>0:   
                res={'success':False,'message':'User already exist'}
                return JsonResponse(res)
            else:
                user=Auth(user_email=uemail,user_pass=upass)
                user.save()
                ekey=(uuid.uuid4()).hex
                user_details=UserDetails(user_id=user.user_id,user_first_name=fname,user_last_name=lname,user_email_verify_key=ekey)
                user_details.save()
                url='http://localhost:8000/ecourt/emailVerify?email='+uemail+'&vkey='+ekey
                try:
                    GMAIL.sendEmail(uemail,url)
                    res={'success':True,'message':'Registration success, email sent on your email id pls verify it.'}
                except:
                    res={'success':True,'message':'Registration success, email sent failed.'}
                return JsonResponse(res)             
        except Exception as e:
            print(e)
            res={'success':False,'message':'Registration failed'}
            return JsonResponse(res) 
    else:
        res={'success':False,'message':'Request is POST not GET'}
        return JsonResponse(res)
    
def emailVerify(request):
    if request.method == 'GET':
        print((request.GET).get('email',None))
        uemail = (request.GET).get('email',None)
        vkey = (request.GET).get('vkey',None)
        val = (uemail,)
        mycursor.execute("SELECT `user_id` FROM ecourt.auth where user_email=%s",val)
        myresult = mycursor.fetchone()
        if myresult is not None:
            if(len(myresult)>0):
                val = (myresult[0],vkey,)
                mycursor.execute("SELECT `user_id` FROM ecourt.user_details where `user_id`=%s and user_email_verify_key=%s",val)
                myresult = mycursor.fetchone()
                if myresult is not None:
                    if(len(myresult)>0):
                        val = (myresult[0],)
                        mycursor.execute("UPDATE ecourt.user_details set user_email_verfied='Y' where `user_id`=%s",val)
                        mydb.commit()
                        res={'success':True,'message':'Email verified successfully !'}
                        return JsonResponse(res)
                    else:
                        res={'success':False,'message':'Email verification failed please request for new email verfication link'}
                        return JsonResponse(res)
                else:
                    res={'success':False,'message':'Email verification failed please request for new email verfication link'}
                    return JsonResponse(res)
                     
            else:
                res={'success':False,'message':'Email verification failed as user does not exist in our record'}
                return JsonResponse(res)
        else:
            res={'success':False,'message':'Email verification failed as user does not exist in our record'}
            return JsonResponse(res)
    else:
        res={'success':False,'message':'Request is GET not POST'}
        return JsonResponse(res)
    
def feedback(request):
    if request.method == 'POST':
        try:
            content =json.loads(request.body)
            uname=content['uname']
            ufeed=content['ufeed']
            uemail=content['uemail']
            umob=content['umob']
            feed=Feedback(user_name=uname,feedback_text=ufeed,uemail=uemail,umob=umob)
            feed.save()
            res={'success':True,'message':'Feedback Submitted'}
            return JsonResponse(res)            
        except Exception as e:
            print(e)
            res={'success':False,'message':'Something went wrong '}
            return JsonResponse(res)  
    else:
        res={'success':False,'message':'Request is POST not GET'}
        return JsonResponse(res)
    
from django.apps import AppConfig


class EcourtappConfig(AppConfig):
    name = 'ecourtapp'

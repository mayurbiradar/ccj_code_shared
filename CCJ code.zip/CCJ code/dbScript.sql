create table ecourt.user_details (
user_details_id int (8) unique primary key not null auto_increment,
user_id int(8) not null unique references auth(user_id),
user_first_name varchar(200),
user_last_name varchar(200),
user_email_verify_key varchar(200) not null unique,
user_email_verified char default 'N' not null,
user_created_on timestamp default current_timestamp
);

create table ecourt.auth
 (
user_id int (8) unique primary key not null auto_increment,
user_email varchar(200) not null unique,
user_pass varchar(100) not null,
created_on timestamp default current_timestamp
);


create table ecourt.journals
 (
journal_id int (8) unique primary key not null auto_increment,
journal_state varchar(100) not null,
journal_title varchar(200) not null,
journal_date varchar(200) not null,
journal_path varchar(500) not null,
journal_content longtext not null,
FULLTEXT (journal_content),
created_on timestamp default current_timestamp
) ENGINE=InnoDB;

	
CREATE FULLTEXT INDEX journal_content_index
ON ecourt.journals(journal_content);

SET SQL_SAFE_UPDATES = 0;
select * from ecourt.auth;
select * from ecourt.user_details;
SELECT * FROM ecourt.auth where user_email=true and user_email_verify_key=true;


select * from `ecourt`.`journals`;


SELECT * FROM `ecourt`.`journals` WHERE MATCH(journal_content)
AGAINST('judge' IN NATURAL LANGUAGE MODE);






create table ecourt.journals2
 (
journal_id int (8) unique primary key not null auto_increment,
diary_number varchar(100) ,
case_number varchar(1024) ,
judgement_date varchar(100),
pdf_file_path varchar(2048) ,
petitioner_name varchar(2048) ,
respondent_name varchar(2048) ,
petitioner_advocate varchar(2048) ,
respondent_advocate varchar(2048) ,
bench longtext,
judgement_by varchar(2048),
journal_state varchar(200),
journal_content longtext not null,
FULLTEXT (journal_content),
created_on timestamp default current_timestamp
) ENGINE=InnoDB;


create table ecourt.feedback (
feedback_id int (8) unique primary key not null auto_increment,
user_name varchar(200),
uemail varchar(200),
umob varchar(200),
feedback_text longtext,
submitted_on timestamp default current_timestamp
);

ALTER TABLE ecourt.journals
ADD journal_keyword longtext;

CREATE FULLTEXT INDEX journal_keyword_index
ON ecourt.journals(journal_keyword);


create table ecourt.sections (
section_id int (8) unique primary key not null auto_increment,
section_name varchar(200),
journal_id int (8) not null references journals(journal_id),
created_on timestamp default current_timestamp
);